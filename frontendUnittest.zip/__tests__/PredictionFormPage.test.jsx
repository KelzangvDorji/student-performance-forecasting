import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import PredictionFormPage from '../PredictionFormPage';
import { createPrediction } from '../../services/predictionService';
import { usePrediction } from '../../hooks/usePrediction';
import { toast } from 'sonner';

const mockNavigate = vi.fn();

// Mock dependencies
vi.mock('react-router-dom', async () => {
    const actual = await vi.importActual('react-router-dom');
    return {
        ...actual,
        useNavigate: () => mockNavigate,
    };
});

vi.mock('../../services/predictionService', () => ({
    createPrediction: vi.fn(),
}));

vi.mock('../../hooks/usePrediction', () => ({
    usePrediction: vi.fn(),
}));

vi.mock('sonner', () => ({
    toast: {
        success: vi.fn(),
        error: vi.fn(),
    },
}));

vi.mock('../../components/Header', () => ({
    default: () => <div data-testid="mock-header">Mock Header</div>,
}));

describe('PredictionFormPage', () => {
    const mockSetLastPrediction = vi.fn();

    beforeEach(() => {
        vi.clearAllMocks();

        usePrediction.mockReturnValue({
            setLastPrediction: mockSetLastPrediction,
        });
    });

    it('renders all form fields', () => {
        render(
            <BrowserRouter>
                <PredictionFormPage />
            </BrowserRouter>
        );

        expect(screen.getByLabelText(/student name/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/enrollment number/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/age/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/gender/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/department/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/midsem 1 marks/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/midsem 2 marks/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/comprehensive exam/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/attendance/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/study hours/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/total backlogs/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/current gpa/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/parent education level/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/part-time job/i)).toBeInTheDocument();
    });

    it('updates form state on input change', () => {
        render(
            <BrowserRouter>
                <PredictionFormPage />
            </BrowserRouter>
        );

        const nameInput = screen.getByLabelText(/student name/i);
        fireEvent.change(nameInput, { target: { value: 'John Doe' } });
        expect(nameInput.value).toBe('John Doe');

        const ageInput = screen.getByLabelText(/age/i);
        fireEvent.change(ageInput, { target: { value: '20' } });
        expect(ageInput.value).toBe('20');
    });

    it('submits form successfully', async () => {
        createPrediction.mockResolvedValue({
            prediction: { cgpa: 8.5, risk: 'Low' },
        });

        render(
            <BrowserRouter>
                <PredictionFormPage />
            </BrowserRouter>
        );

        // Fill in required fields
        fireEvent.change(screen.getByLabelText(/student name/i), { target: { value: 'John' } });
        fireEvent.change(screen.getByLabelText(/enrollment number/i), { target: { value: '123' } });
        fireEvent.change(screen.getByLabelText(/age/i), { target: { value: '20' } });
        fireEvent.change(screen.getByLabelText(/midsem 1 marks/i), { target: { value: '80' } });
        fireEvent.change(screen.getByLabelText(/midsem 2 marks/i), { target: { value: '85' } });
        fireEvent.change(screen.getByLabelText(/comprehensive exam/i), { target: { value: '90' } });
        fireEvent.change(screen.getByLabelText(/attendance/i), { target: { value: '95' } });
        fireEvent.change(screen.getByLabelText(/study hours/i), { target: { value: '10' } });
        fireEvent.change(screen.getByLabelText(/total backlogs/i), { target: { value: '0' } });
        fireEvent.change(screen.getByLabelText(/current gpa/i), { target: { value: '8.5' } });

        // Submit
        const submitButton = screen.getByRole('button', { name: /generate prediction/i });
        fireEvent.click(submitButton);

        await waitFor(() => {
            expect(createPrediction).toHaveBeenCalled();
        });

        expect(mockSetLastPrediction).toHaveBeenCalled();
        expect(toast.success).toHaveBeenCalledWith('Prediction generated');
        expect(mockNavigate).toHaveBeenCalledWith('/results');
    });

    it('handles submission error', async () => {
        createPrediction.mockRejectedValue({
            response: { data: { error: 'API Error' } },
        });

        render(
            <BrowserRouter>
                <PredictionFormPage />
            </BrowserRouter>
        );

        // Fill in required fields (minimal to trigger submit)
        fireEvent.change(screen.getByLabelText(/student name/i), { target: { value: 'John' } });
        fireEvent.change(screen.getByLabelText(/enrollment number/i), { target: { value: '123' } });
        fireEvent.change(screen.getByLabelText(/age/i), { target: { value: '20' } });
        fireEvent.change(screen.getByLabelText(/midsem 1 marks/i), { target: { value: '80' } });
        fireEvent.change(screen.getByLabelText(/midsem 2 marks/i), { target: { value: '85' } });
        fireEvent.change(screen.getByLabelText(/comprehensive exam/i), { target: { value: '90' } });
        fireEvent.change(screen.getByLabelText(/attendance/i), { target: { value: '95' } });
        fireEvent.change(screen.getByLabelText(/study hours/i), { target: { value: '10' } });
        fireEvent.change(screen.getByLabelText(/total backlogs/i), { target: { value: '0' } });
        fireEvent.change(screen.getByLabelText(/current gpa/i), { target: { value: '8.5' } });

        const submitButton = screen.getByRole('button', { name: /generate prediction/i });
        fireEvent.click(submitButton);

        await waitFor(() => {
            expect(createPrediction).toHaveBeenCalled();
        });

        expect(toast.error).toHaveBeenCalledWith('API Error');
        expect(mockNavigate).not.toHaveBeenCalled();
    });
});

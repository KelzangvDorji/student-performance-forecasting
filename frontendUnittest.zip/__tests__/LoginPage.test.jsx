import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import LoginPage from '../LoginPage';

// Mock dependencies
vi.mock('react-router-dom', () => ({
    useNavigate: () => vi.fn(),
}));

vi.mock('../../hooks/useAuth', () => ({
    useAuth: () => ({
        login: vi.fn(),
    }),
}));

vi.mock('../../services/authService', () => ({
    signin: vi.fn(),
    signup: vi.fn(),
}));

describe('LoginPage', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('renders sign in form by default', () => {
        render(<LoginPage />);

        // Check for Sign In button (the one that submits the form)
        // There are multiple "Sign In" buttons, so we find the one with type="submit"
        const buttons = screen.getAllByRole('button', { name: /sign in/i });
        const submitButton = buttons.find(btn => btn.getAttribute('type') === 'submit');
        expect(submitButton).toBeInTheDocument();

        // Check for input fields
        expect(screen.getByPlaceholderText(/you@college.edu/i)).toBeInTheDocument();
        expect(screen.getByPlaceholderText(/minimum 6 characters/i)).toBeInTheDocument();

        // Name field should NOT be there in sign in mode
        expect(screen.queryByPlaceholderText(/dr. jane smith/i)).not.toBeInTheDocument();
    });

    it('switches to signup mode when clicking Sign Up', () => {
        render(<LoginPage />);

        // Find the toggle button (it's in the top right area)
        const signUpToggle = screen.getByRole('button', { name: 'Sign Up' });
        fireEvent.click(signUpToggle);

        // Now the submit button should say "Create account"
        const submitButton = screen.getByRole('button', { name: /create account/i });
        expect(submitButton).toBeInTheDocument();

        // Name field SHOULD be there now
        expect(screen.getByPlaceholderText(/dr. jane smith/i)).toBeInTheDocument();
    });
});

import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import DashboardPage from '../DashboardPage';

// Mock Header component
vi.mock('../../components/Header', () => ({
    default: () => <div data-testid="mock-header">Mock Header</div>,
}));

describe('DashboardPage', () => {
    it('renders dashboard content correctly', () => {
        render(
            <BrowserRouter>
                <DashboardPage />
            </BrowserRouter>
        );

        // Check for Header
        expect(screen.getByTestId('mock-header')).toBeInTheDocument();

        // Check for main title
        expect(screen.getByText(/Predict student success with precision/i)).toBeInTheDocument();

        // Check for stat cards
        expect(screen.getByText('Ready Endpoints')).toBeInTheDocument();
        expect(screen.getByText('ML Service')).toBeInTheDocument();
        expect(screen.getByText('Security')).toBeInTheDocument();

        // Check for values in stat cards
        expect(screen.getByText('12')).toBeInTheDocument();
        expect(screen.getByText('Forecast + Risk')).toBeInTheDocument();
        expect(screen.getByText('JWT Protected')).toBeInTheDocument();
    });

    it('renders action links', () => {
        render(
            <BrowserRouter>
                <DashboardPage />
            </BrowserRouter>
        );

        // Check for "Predict a student" link
        const predictLink = screen.getByRole('link', { name: /predict a student/i });
        expect(predictLink).toBeInTheDocument();
        expect(predictLink).toHaveAttribute('href', '/predict');

        // Check for "Past predictions" link
        const historyLink = screen.getByRole('link', { name: /past predictions/i });
        expect(historyLink).toBeInTheDocument();
        expect(historyLink).toHaveAttribute('href', '/history');
    });

    it('renders flow steps', () => {
        render(
            <BrowserRouter>
                <DashboardPage />
            </BrowserRouter>
        );

        expect(screen.getByText(/Capture student data in the guided form/i)).toBeInTheDocument();
        expect(screen.getByText(/Backend validates and calls the FastAPI ML service/i)).toBeInTheDocument();
        expect(screen.getByText(/MongoDB stores every prediction for history/i)).toBeInTheDocument();
        expect(screen.getByText(/View confidence, CGPA, and risk instantly/i)).toBeInTheDocument();
    });
});

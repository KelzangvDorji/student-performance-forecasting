import time
import random
import string
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import Select

def get_random_string(length=8):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

def run_test():
    print("Starting Selenium Test...")
    
    # Setup Chrome Driver
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)
    driver.maximize_window()
    
    try:
        # 1. Open Frontend
        print("Opening Frontend...")
        driver.get("http://localhost:5173")
        time.sleep(2)
        
        # 2. Signup
        print("Navigating to Signup...")
        # Click "Sign Up" toggle button
        signup_toggle = driver.find_element(By.XPATH, "//button[contains(text(), 'Sign Up')]")
        signup_toggle.click()
        time.sleep(1)
        
        # Fill Signup Form
        print("Filling Signup Form...")
        random_email = f"test_{get_random_string()}@college.edu"
        print(f"Using email: {random_email}")
        
        driver.find_element(By.NAME, "name").send_keys("Test Faculty")
        driver.find_element(By.NAME, "email").send_keys(random_email)
        driver.find_element(By.NAME, "password").send_keys("password123")
        
        # Submit Signup
        submit_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'Create account')]")
        submit_btn.click()
        
        # Wait for redirect to dashboard (or login success toast)
        print("Waiting for login/redirect...")
        WebDriverWait(driver, 10).until(
            EC.url_contains("/dashboard")
        )
        print("Login Successful! Redirected to Dashboard.")
        time.sleep(2)
        
        # 3. Navigate to Prediction Form
        # Assuming there is a button/link to "New Prediction" or similar on dashboard
        # Since I didn't check DashboardPage, I'll try to navigate directly or find a likely button
        # Let's check if we can find a "New Prediction" button or just go to URL
        print("Navigating to Prediction Form...")
        driver.get("http://localhost:5173/predict")
        time.sleep(2)
        
        # 4. Fill Prediction Form
        print("Filling Prediction Form...")
        driver.find_element(By.NAME, "studentName").send_keys("Selenium Student")
        driver.find_element(By.NAME, "enrollmentNumber").send_keys(f"SEL{get_random_string(4).upper()}")
        driver.find_element(By.NAME, "age").send_keys("20")
        
        Select(driver.find_element(By.NAME, "gender")).select_by_value("female")
        Select(driver.find_element(By.NAME, "department")).select_by_value("CSE")
        Select(driver.find_element(By.NAME, "parentEducationLevel")).select_by_value("Graduate")
        Select(driver.find_element(By.NAME, "hasPartTimeJob")).select_by_value("no")
        
        driver.find_element(By.NAME, "midsem1Marks").send_keys("85")
        driver.find_element(By.NAME, "midsem2Marks").send_keys("88")
        driver.find_element(By.NAME, "comprehensiveExamMarks").send_keys("90")
        driver.find_element(By.NAME, "attendancePercentage").send_keys("95")
        driver.find_element(By.NAME, "studyHoursPerWeek").send_keys("10")
        driver.find_element(By.NAME, "totalBacklogs").send_keys("0")
        driver.find_element(By.NAME, "currentGPA").send_keys("8.5")
        
        # 5. Submit Prediction
        print("Submitting Prediction...")
        # Button text is "Generate prediction"
        predict_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'Generate prediction')]")
        predict_btn.click()
        
        # 6. Verify Results
        print("Waiting for results...")
        WebDriverWait(driver, 30).until(
            EC.url_contains("/results")
        )
        print("Redirected to Results Page!")
        
        # Check for some result text
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'Risk Level') or contains(text(), 'Predicted CGPA')]"))
        )
        print("TEST PASSED: Results displayed successfully.")
        
        time.sleep(5) # Keep open for a bit to see
        
    except Exception as e:
        print(f"TEST FAILED: {e}")
        driver.save_screenshot("test_failure.png")
        
        # Check for error toasts
        try:
            toasts = driver.find_elements(By.XPATH, "//li[contains(@data-type, 'error')]")
            for toast in toasts:
                print(f"ERROR TOAST FOUND: {toast.text}")
        except:
            pass

        print("Browser Console Logs:")
        for entry in driver.get_log('browser'):
            print(entry)
            
        print("Page Source (First 2000 chars):")
        print(driver.page_source[:2000])
            
        raise
    finally:
        print("Closing browser...")
        driver.quit()

if __name__ == "__main__":
    run_test()
